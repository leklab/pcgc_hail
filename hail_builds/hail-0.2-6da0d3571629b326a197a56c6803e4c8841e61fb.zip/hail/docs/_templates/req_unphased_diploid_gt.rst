.. note::

    Requires the dataset to contain only diploid and unphased genotype calls.
    Use :func:`.call` to recode genotype calls or :func:`.null` to set genotype
    calls to missing.