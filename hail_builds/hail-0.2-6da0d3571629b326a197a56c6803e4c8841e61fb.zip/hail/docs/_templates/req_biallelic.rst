.. note::

    Requires the dataset to contain no multiallelic variants.
    Use :func:`.split_multi` or :func:`.split_multi_hts` to split
    multiallelic sites, or :meth:`.MatrixTable.filter_rows` to remove
    them.