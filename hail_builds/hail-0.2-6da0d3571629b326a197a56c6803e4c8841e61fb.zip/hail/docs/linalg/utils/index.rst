linalg/utils
============

.. currentmodule:: hail.linalg.utils

.. autosummary::

    array_windows
    locus_windows

.. autofunction:: array_windows
.. autofunction:: locus_windows
