Miscellaneous
-------------

.. currentmodule:: hail.methods

.. toctree::
    :maxdepth: 2

.. autosummary::

    grep
    maximal_independent_set
    rename_duplicates

.. autofunction:: grep
.. autofunction:: maximal_independent_set
.. autofunction:: rename_duplicates